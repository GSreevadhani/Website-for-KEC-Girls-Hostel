<?php

//submit_rating.php

$connect = new PDO("mysql:host=localhost;dbname=students", "root", "");
$data=$_POST["user_email"];
$query = "
SELECT * FROM email_id";
$statement = $connect->prepare($query);

	$statement->execute();
	$r = $statement->setFetchMode(PDO::FETCH_ASSOC);
      // FETCHING DATA FROM DATABASE
      $result = $statement->fetchAll();
	  foreach ($result as $row) 
      {
         if($data==$row["email"]){
      

		if(isset($_POST["rating_data"]))
		{

			$data = array(
				':user_email'		=> $_POST["user_email"],
				':user_name'		=>	$_POST["user_name"],
				':user_rating'		=>	$_POST["rating_data"],
				':user_review'		=>	$_POST["user_review"],
				':datetime'			=>	time()
			);

			$query = "
			INSERT INTO review_table 
			(user_email,user_name, user_rating, user_review, datetime) 
			VALUES (:user_email,:user_name, :user_rating, :user_review, :datetime)
			";

			$statement = $connect->prepare($query);

			$statement->execute($data);

			echo "Your Review & Rating Successfully Submitted";
		}
		$flag=1;
		break;
	  	}
	  else
	    $flag=0;
	  }
	  if($flag==0)
	     echo "Invalid Email Id";
?>